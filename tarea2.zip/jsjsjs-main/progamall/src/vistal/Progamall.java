/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package vistal;

/**
 *
 * @author augus
 */
public class Progamall {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        program_fr frm = new program_fr();
        frm.show();

        
        // TODO code application logic here
    }
    
}
